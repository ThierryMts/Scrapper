#!/usr/bin/env ruby
require 'rubygems'
require 'nokogiri'
require 'open-uri'

doc = Nokogiri::HTML(open('http://annuaire-des-mairies.com/95/vaureal.html'))
doc.css('p:contains("@")').each do |node|
puts node.text
end