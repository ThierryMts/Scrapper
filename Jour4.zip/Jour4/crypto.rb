require 'nokogiri'
require 'open-uri'

html = open("https://coinmarketcap.com/all/views/all/")
doc = Nokogiri::HTML(html)

doc.search('tr').map do |element|
	puts element.inner_text

end